function getme(){
  var mem=process.memoryUsage();
  var format=function(bytes){
    return (bytes/1024/1024).toFixed(2)+"MB";
  }
  console.log('heapTotal: '+format(mem.heapTotal)+
    '              heapUsed: '+format(mem.heapUsed)
  )
}
 
/*var a=[];
for(var i=0;i<15;i++){
  var size=20*1024*1024;
  var arr1=new Array(size);
  if(a.length>4){
    a.shift();
  }
  a.push(arr1);
}
getme();*/


/*var size=20*1024*1024;
(function(){
  var arr1=new Array(size);
})();

(function(){
  var arr2=new Array(size);
})();

(function(){
 var arr3=new Array(size);
})();

(function(){
  var arr4=new Array(size);
})();

(function(){
  var arr5=new Array(size);
})();

(function(){
  var arr6=new Array(size);
})();

(function(){
  var arr7=new Array(size)
})();

(function(){
 var arr8=new Array(size);
})();
(function(){
  var arr9=new Array(size);
})();*/
/*function a(){
  var size=20*1024*1024;
  var arr1=new Array(size);
  return arr1;
}
var b=a();
var c=a();
var d=a();
var e=a();
var f=a();
var g=a();
var h=a();
var i=a();
var j=a();
var k=a();
var l=a();
var m=a();
var n=a();
var o=a();
var p=a();
var q=a();
getme();*/

/*for(var i=10000;i<10050;i++){
   (function(i){
    console.log(i);
    getme();
   })(i)
}*/