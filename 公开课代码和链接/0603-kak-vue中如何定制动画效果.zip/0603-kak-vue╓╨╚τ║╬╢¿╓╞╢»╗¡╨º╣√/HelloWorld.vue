<template>
  <div class="hello">
     <div class='tab-title'>
        <span @click="changetab(0)">tab1</span>
        <span @click="changetab(1)">tab2</span>
        <span @click="changetab(2)">tab3</span>
     </div>
     <animation :type="{
      beforenter:{name:'opacity',value:0},
      enter:{name:'opacity',value:1,time:1000},
      leave:{name:'opacity',value:0,time:200}
      }">
       <div v-if='state==0'  key="tab1" >i am table one</div>
       <div v-else-if="state==1" key='tab2'>i am table two</div>
       <div v-else key='tab3'>i am table three</div>       
     </animation>
     <!--<transition name='tab-change'> 
       <div v-if='state==1'  key="tab1" :style="'display:'+(state==0?'block':'none')">i am table one</div>
    </transition>
       <div v-if="state==1" key='tab2'>i am table two</div>
 
       <div v-if="state==2" key='tab3'>i am table three</div>-->

     <!--<transition  
       v-on:before-enter='beforenter' 
       v-on:enter='enter' 
       v-on:after-enter="afterenter"
       v-on:leave="leave"
     > 
       <div v-if='state==0'  key="tab1" >i am table one</div>
       <div v-else-if="state==1" key='tab2'>i am table two</div>
       <div v-else key='tab3'>i am table three</div>
     </transition> -->  
    <div class='test2'>
       <button @click='move'>动起来</button>
       <div :style="'margin-left:'+margin+'px'">
          我是一个移动的小可爱
       </div>
    </div>
    <div class='test2'>
       <button @click='move2'>动起来</button>
       <div  ref="mover" >
          我是一个移动的小可爱
       </div>
    </div>
  </div>
  

</template>
<script>
import '../../static/animation.css'
import animation from './animation.vue'
import mymove from '../../static/move.js'
import axios from "axios";

export default {
  name: "HelloWorld",
  data:function(){
   return {
     state:0,
     margin:0
   }
  },
  components:{
    animation:animation
  },
  mounted:function(){ 
  },
  methods:{
    changetab:function(num){
      this.state=num;
    },
    beforenter:function(el){
       el.style.opacity=0;
    },
    enter:function(el,done){  
      Velocity(el, {opacity: 1},{ duration: 1000 },{ complete: done })
    },
    beforeleave:function(el){
       el.style.opacity=1;
    },    
    leave:function(el){
      Velocity(el, {opacity: 0},{ duration:1000 });
      console.log(1);
    },
    afterenter:function(){
  
    },
    move:function(){
      setInterval(()=>{
        this.margin++;
      },10);
    },
    move2:function(){
       
      mymove(this.$refs.mover);
    }    
  }
}
</script>
<style>
 
.tab-change-enter-active {
 animation:bounceInRight 1s;
 display:none;
}
.tab-change-leave-active {
  display:block;
  animation:bounceOutRight 1s;
}
.tab-change-enter
{
   
}
.tab-change-leave-to{
  
}
</style>

 
