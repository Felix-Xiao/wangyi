<template>
   <div>
     <!--<transition :name="type">
       <slot></slot>
     </transition>-->
     <transition  
       v-on:before-enter='beforenter' 
       v-on:enter='enter' 
       v-on:after-enter="afterenter"
       v-on:leave="leave"
     >
       <slot></slot>
     </transition>       
   </div>

</template>
<script>
import axios from "axios";
import '../../static/animation.css'
export default {
  name: "animation",
  props:['type'],
  data:function(){
   return {
     mytype:'fade',

   }
  },
  mounted:function(){
    console.log(this.type);
  },
  methods:{
    beforenter:function(el){
       el.style[this.type.beforenter.name]=0;
    },
    enter:function(el,done){
      var arr=[];
      /*if(typeof this.type=='string'){
        arr=this.typearr.[this.type].enter;
      }else{
        var enter=this.type.enter
        _value[enter.name]=enter.value; 
        arr=[_value,{ duration: enter.time }];
      }*/
      Velocity(el, _value,{ duration: enter.time },{ complete: done })
    },
    
    leave:function(el){
      var leave=this.type.leave
      var _value={};
      _value[leave.name]=leave.value;       
      Velocity(el, _value,{ duration:leave.time });
    },
    afterenter:function(){
  
    },
  }
}
</script>
<style>
 .bounce-enter-active {
 animation:bounceInRight 1s;
 display:none;
}
.bounce-leave-active {
  display:block;
  animation:bounceOutRight 1s;
}
.bounce-enter
{
   
}
.bounce-leave-to{
  
}
.fade-enter-active {
  transition: all .3s ease;
}
.fade-leave-active {
  transition: all .8s cubic-bezier(1.0, 0.5, 0.8, 1.0);
}
.fade-enter, .fade-leave-to
 {
  transform: translateX(10px);
  opacity: 0;
}
</style>

 
