var request=require('request');

async function index (){
 var getAllclassify=await new Promise(function(resolve,reject){
      request.get('http://localhost:3000/getAllclassify',function(err,response,data){
              resolve(JSON.parse(data));
      })
 })
 var getIndexpic=await new Promise(function(resolve,reject){
      request.get('http://localhost:3000/getIndexpic',function(err,response,data){
               resolve(JSON.parse(data));
      }) 
 })
 var getMore=await new Promise(function(resolve,reject){
      request.get('http://localhost:3000/getMore',function(err,response,data){
               resolve(JSON.parse(data));
      }) 
 })
 var getHot=await new Promise(function(resolve,reject){
      request.get('http://localhost:3000/getHot',function(err,response,data){
              resolve(JSON.parse(data));
      }) 
 });  
 var getFloor=await new Promise(function(resolve,reject){
      request.get('http://localhost:3000/getFloor',function(err,response,data){
               resolve(JSON.parse(data));
      })  
 }); 
 
 return {
 	getAllclassify:getAllclassify,
 	getMore:getMore,
 	getHot:getHot,
 	getIndexpic:getIndexpic,
 	getFloor:getFloor,
 };
};
module.exports=index;