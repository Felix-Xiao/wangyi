var request=require('request');
var getIndex=require('../../model/index.js');
 
function index(req,res){
 
       getIndex().then(function(data){ 
 
            res.render('index.art',data);
        }).catch(err=>{
 
        });   
}
module.exports=index;