//缓存架构应该满足一下几点：
// 1.兼容性（原生js）
// 2.开闭原则（设计模式）
// 3.扩展性（无论资源还是数据缓存，无论内存还是文件或者是数据库）
// 4.应用起来要简单
// 5.面向接口的设计

(function( global, factory, name){

    return global[name] = factory.call(global);

})( this, function(){
    var __E_TYPES__ = {
        MEMORY : "MEMORY"
    };
    //缓存引擎
    var __ENGINES__ = {
        [__E_TYPES__.MEMORY] : {
            init : function(){
                this.pools = this.pools||{};
            },
            set : function(options){
                this.pools[options.key] = options.data;
            },
            get : function(options){
                return this.pools[options.key];
            },
            remove : function(){
                delete this.pools[options.key];
            }
        }
    };
    __ENGINES__[__E_TYPES__.MEMORY].init();
    //保护架构的核心功能
    var __CACHES__ = {
        install : function(type,object){
            __E_TYPES__[type] = type;
            __ENGINES__[type] = object;
            __ENGINES__[type].init();
        },//安装某一个缓存机制
        uninstall : function(){},//卸载某一个缓存机制
        set : function(type,ops){
            __ENGINES__[type].set(ops);
        },//存
        get : function(type,ops){
            return __ENGINES__[type||__E_TYPES__.MEMORY].get(ops);
        },//取
        remove : function(){
            __ENGINES__[type||__E_TYPES__.MEMORY].remove(ops);
        }
    };
    return {
        TYPES : __E_TYPES__,
        getInstance : function(){
            return __CACHES__;
        }
    };
},"NetEaseCaches");