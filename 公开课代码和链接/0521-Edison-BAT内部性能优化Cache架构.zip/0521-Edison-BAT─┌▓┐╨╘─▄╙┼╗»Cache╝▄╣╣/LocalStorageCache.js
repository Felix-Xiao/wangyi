NetEaseCaches.getInstance().install(NetEaseCaches.TYPES.LOCAL_STRONAGE,{
    init:function(){
        
    },
    set : function(){
        
    },
    get : function(){
        console.log(localStorage);
    }
});