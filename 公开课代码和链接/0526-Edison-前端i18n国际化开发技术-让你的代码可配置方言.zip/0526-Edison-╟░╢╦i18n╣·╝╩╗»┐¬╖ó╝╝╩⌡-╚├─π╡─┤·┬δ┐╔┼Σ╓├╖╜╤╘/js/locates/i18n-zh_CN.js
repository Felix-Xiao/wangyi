I18N.register("zh_CN",{
    baseConfig : "基本配置",
    userInfo : "用户信息",
    orgManage : "角色管理",
    roleManage : "权限管理",
    systemManage : "系统管理"
});