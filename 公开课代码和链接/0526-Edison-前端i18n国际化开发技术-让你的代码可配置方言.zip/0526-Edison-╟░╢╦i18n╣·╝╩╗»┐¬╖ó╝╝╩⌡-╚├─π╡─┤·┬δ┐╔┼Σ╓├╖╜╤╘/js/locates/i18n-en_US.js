I18N.register("en_US",{
    baseConfig : "Basic Config",
    userInfo : "Users Information",
    orgManage : "Orgs Manage",
    roleManage : "Roles Manage",
    systemManage : "System Manage"
});
I18N.register("zh_CN",{
    baseConfig : "基本配置",
    userInfo : "用户信息",
    orgManage : "角色管理",
    roleManage : "权限管理",
    systemManage : "系统管理"
});
I18N.register("zh_TW",{
    baseConfig : "基本信息",
    userInfo : "用戶信息",
    orgManage : "角色管理",
    roleManage : "權限管理",
    systemManage : "系統管理"
});