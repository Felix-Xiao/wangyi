I18N.register("zh_TW",{
    baseConfig : "基本信息",
    userInfo : "用戶信息",
    orgManage : "角色管理",
    roleManage : "權限管理",
    systemManage : "系統管理"
});