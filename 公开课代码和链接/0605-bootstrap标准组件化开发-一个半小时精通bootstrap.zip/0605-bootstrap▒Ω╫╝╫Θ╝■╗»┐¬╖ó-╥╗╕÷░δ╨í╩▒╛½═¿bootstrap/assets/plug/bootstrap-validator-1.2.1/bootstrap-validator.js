//author : edison
;(function(global , factory , plug){
    //
    return factory.call(global , global.jQuery , plug);
})( typeof window === "undefined" ? this : window , function($ , plug){
    //
    var __DEFS__ = {
        "raise" : "change",
        "errMsg" : "* 校验失败"
    }
    //规则引擎
    var __RULES__ = {
        "require" : function(){
            // return this.value!=undefined && this.value!=null && this.value!="";
            return !!(this.val());
        },//   必须填写
        "mobile" : function(){
            return /^1\d{10}$/.test(this.val());
        },//    必须是移动手机号码
        "date"  : function(){
            return false;
        },//     必须是日期（yyyy-MM-dd   yyyy/MM/dd    Y-M-D H:i:s）
        "email"  : function(){
            return /^\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$/.test(this.val());
        },//    必须是邮箱格式
        "regex"  : function(regex){
            return new RegExp(regex).test(this.val());
        },//    必须匹配正则表达式
        "number"  : function(){
            return false;
        },//   必须是数字  -11.111111
        "phone"  : function(){
            return false;
        },//    必须是电话号码
        "length"  : function(){
            return false;
        },//   必须是多少位
        "amount"  : function(){
            return false;
        },//   必须是金额
        "date"  : function(date){
            var d = this.data("bv-date-value");
            date = date.replace("y",d.getFullYear())
            .replace("M",d.getMonth()+1)
            .replace("d",d.getDate())
            .replace("h",d.getHours())
            .replace("m",d.getMinutes())
            .replace("s",d.getSeconds());
            return false;
        }
        //...
    };
    $.fn[plug] = function(ops){
        if(this.is("form")){
            var that = this;
            var $fileds = this.find("[data-bv]");
            $.extend(this,__DEFS__,ops);//先后扩展__DEFS__ 和 ops的属性值给this
            $fileds.on(this.raise,function(){
                var $f = $(this);//被校验的元素
                var $g = $f.parents(".form-group:first").removeClass("has-success").removeClass("has-error");
                $g.find(".help-block").remove();
                var res = true;//默认校验成功
                $.each(__RULES__,function(rule,valid){
                    var v = $f.data("bv-"+rule);
                    if(v){
                        res = valid.call($f,v);
                        $g.addClass(res?"has-success":"has-error");
                        if(!res){
                            $f.after('<span class="help-block">'+($f.data("bv-"+rule+"-error") || that.errMsg)+'</span>');
                        }
                        return res;
                    }
                });
            });
            this.extendRules = function(rules){
                $.extend(__RULES__,rules);
            }
            return this;
        }else{
            throw new Error("require is form element");
        }
    }

} , "bootstrapValidator");