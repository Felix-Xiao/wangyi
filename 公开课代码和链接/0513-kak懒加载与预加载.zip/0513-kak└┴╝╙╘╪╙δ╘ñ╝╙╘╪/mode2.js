
  console.log(2);
 