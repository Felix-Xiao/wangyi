import Vue from 'vue'
import Router from 'vue-router'
 
 
Vue.use(Router)

export default new Router({
  routes: [
    {
      path: '/',
      name: 'HelloWorld',
     // component:()=>import("@/components/HelloWorld")
      component:resolve=>require.ensure([],()=>resolve(require("@/components/HelloWorld")))
    },
    {
      path: '/pop',
      name: 'pop',
      //component: ()=>import( "@/components/pop")
      
      component: resolve=>require.ensure([],()=>resolve(require("@/components/pop")))
    },    
  ]
})
