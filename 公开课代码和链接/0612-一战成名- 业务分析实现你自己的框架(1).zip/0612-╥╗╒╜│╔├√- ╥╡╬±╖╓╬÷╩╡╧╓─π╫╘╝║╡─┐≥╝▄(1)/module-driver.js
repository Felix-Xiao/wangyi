var $MD = (function( global , factory , plug){
    return global[plug] = factory.call(global);
})( this , function(){
    var __M__ = {};
    var __D__ = {
        init : function(data,modules){
            __M__ = modules || __M__;
            this.load(data);
        },
        load : function(data){
            this.fetch(data);
            this.refresh();
        },
        fetch : function(data){
            //开闭原则
            for(var _m_ in __M__){
                __M__[_m_].lock = !!(__M__[_m_].model = data[_m_] || null);
            }
        },
        refresh : function(){
            for(var _m_ in __M__){
                __M__[_m_].lock && __M__[_m_].render && __M__[_m_].render();
            }
        }
    };
    return __D__;
} , "ModuleDriver");