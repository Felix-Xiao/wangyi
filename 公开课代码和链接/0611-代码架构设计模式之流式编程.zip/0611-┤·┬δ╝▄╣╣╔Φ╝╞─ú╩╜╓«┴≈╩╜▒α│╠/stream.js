(function(root) {
	//构造函数
	var stram = function(obj) {
		if (!(this instanceof stram)) {
			return new stram(obj);
		}
		this.wrap = obj; //数据源
	}

	//函数对象  [this.wrap, funcition(){}]
	stram.unique = function(array, callback) {
		//逻辑处理
		var result = [];
		for (var i = 0; i < array.length; i++) {
			var target = callback ? callback(array[i]) : array[i];
			if (result.indexOf(target) === -1) {
				result.push(target)
			}
		}
		return result;
	}

	stram.map1 = function(array) {    //unique输入   
      array.push("max");   //逻辑处理
	  return array;   //输出
	}

	//开启链接式的调用
	stram.chain = function(obj) {
       var instance = stram(obj);
	   instance._chain = true;   //凭证
	   return instance;
	}
	
	//实例对象  上道工序处理的结果obj
	stram.reuslt = function(instance, obj){
		if(instance._chain){
		   instance.wrap = obj;
		   return instance;
		}
		return obj;
	}
	
	stram.prototype.values = function(){
		return this.wrap;
	}

	stram.functions = function(obj) {
		var result = []; //查找  所以属性的名称
		var key;
		for (key in obj) {
			result.push(key);
		}
		return result;
	}

	stram.each = function(array, callback) {
		for (var i = 0, length = array.length; i < length; i++) {
			callback.call(array, array[i], i);
		}
	}
	//骚想法  查找  属性   复制一份到原型上面去
	stram.mixin = function(obj) {
		stram.each(stram.functions(obj), function(name) {
			var func = stram[name];
			stram.prototype[name] = function() {
				var args = [this.wrap];
				[].push.apply(args, arguments); //args == []   [this.wrap, funcition(){}]
				return stram.reuslt(this, func.apply(this, args));   // 辅助函数 this  === instance    func.apply(this, args) === 处理结果
			}
		});
	}

	stram.mixin(stram);
	root.stram = stram;
})(this);


//	console.log(unique([1, 2, 3, 4, 5, 3, 4, 5]).map1())    支持  问题   数据

//   面向对象编程+函数式编程


//prototype.js  css   show  hidde  ...   库     扩展
