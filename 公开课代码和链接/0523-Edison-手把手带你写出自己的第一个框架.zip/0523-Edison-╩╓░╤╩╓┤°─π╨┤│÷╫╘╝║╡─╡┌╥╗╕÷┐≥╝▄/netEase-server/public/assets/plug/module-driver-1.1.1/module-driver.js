;(function(global , factory , plug){
    global[plug] = factory.call(global);
})(this , function(){
    var __MODULUS__ = {

    };
    var __DRIVER__ = {
        init : function(config){
            for(var m in config){
                __MODULUS__[m] = config[m];
            }
        },
        load : function(meta){
            this.fetch(meta);
            this.render();
        },
        fetch : function(meta){
            for(var m in __MODULUS__){
                if(meta[m]){
                    __MODULUS__[m].model =  meta[m];
                    __MODULUS__[m].lock = true;//把渲染锁打开
                }
            }
        },
        render : function(){
            for(var m in __MODULUS__){
                if(__MODULUS__[m].lock){
                    __MODULUS__[m].render && __MODULUS__[m].render();
                    __MODULUS__[m].lock = false;//把渲染锁关闭
                }
            }
        }
    };

    return __DRIVER__;
} , "ModuleDriver");