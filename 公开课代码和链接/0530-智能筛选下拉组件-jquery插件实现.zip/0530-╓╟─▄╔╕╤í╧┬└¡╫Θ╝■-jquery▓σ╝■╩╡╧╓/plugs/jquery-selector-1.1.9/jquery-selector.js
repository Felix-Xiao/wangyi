(function(global , factory , plug){
    factory.call(global , global.jQuery, plug);
})(this , function($,plug){
    var __TEMP__ =  '    <input class="jq-input" placeholder="{{placeholder}}">'+
                    '   <a href="javascript:;" class="jq-addon pbd_input_btn">{{addon}}</a>'+
                    '   <div class="add_Fund jhzz_tx_box" style="display: block;">'+
                    '       <div class="layer_box">'+
                    '           <div class="jhzz_tx_tit">'+
                    '               <label class="focus_dis">'+
                    '                   <span style="display: block;">{{keyhint}}</span>'+
                    '                   <input class="input_txt pbd_input_new" type="text" value="">'+
                    '               </label>'+
                    '           </div>'+
                    '           <div class="jhzz_tx_txt">'+
                    '               <div class="slimScrollDiv" style="position: relative; width: 300px; height: 165px;"><div class="jhzz_scroll_box" style=" width: 300px; height: 165px;">'+
                    '                   <ul>{{dataList}}</ul>'+
                    '               </div>'+
                    '           </div>'+
                    '       </div>'+
                    '   </div>';
    var __DEFS__ = {
        placeholder : "",
        addon : "",
        keyhint : "",
        render : function(){},
        url : ""
    };
    var __PROTO__ = {
        __init : function(ops){
            var __T__ = __TEMP__;
            this.ops = {};
            var that = this;
            for(var prop in __DEFS__){
                this.ops[prop] = ops[prop] || this.data("js-"+prop) || __DEFS__[prop];
                __T__ = __T__.replace("{{"+prop+"}}",this.ops[prop]);
            }
            this.request(function(list){
                var __L__ = "";
                for(var i=0;i<list.length;i++){
                    var o = that.ops.render(list[i]);
                    __L__+=`<li style="display: block;"><i class="${o.icon}"></i><span>${o.text}</span><em></em></li>`;
                }
                __T__ = __T__.replace("{{dataList}}",__L__);
                that.html(__T__);
            });
        },
        request : function(callback){
            var _that = this;
            $.getJSON(this.ops.url,function(data){
                callback(data);
            })
        },
        handler : function(){
            var that = this;
            $(this).on("keyup",".pbd_input_new",function(event){
                var val = this.value;
                var $lis = $(".jhzz_scroll_box ul li span:contains("+val+")",that).parent();
                $lis.siblings().hide();
                $lis.show();
            });
        }
    };
    $.fn[plug] = function(ops){
        var $this = $(this);
        $.extend($this,__PROTO__);
        $this.__init(ops);
        $this.handler();
        return $this;
    }
}, "selector");